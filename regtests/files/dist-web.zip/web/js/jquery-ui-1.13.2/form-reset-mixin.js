/*
 jQuery UI Form Reset Mixin 1.13.2
 http://jqueryui.com

 Copyright OpenJS Foundation and other contributors
 Released under the MIT license.
 http://jquery.org/license
*/
(function(b){"function"===typeof define&&define.amd?define(["jquery","./form","./version"],b):b(jQuery)})(function(b){return b.ui.formResetMixin={_formResetHandler:function(){var a=b(this);setTimeout(function(){var c=a.data("ui-form-reset-instances");b.each(c,function(){this.refresh()})})},_bindFormResetHandler:function(){this.form=this.element._form();if(this.form.length){var a=this.form.data("ui-form-reset-instances")||[];if(!a.length)this.form.on("reset.ui-form-reset",this._formResetHandler);a.push(this);
this.form.data("ui-form-reset-instances",a)}},_unbindFormResetHandler:function(){if(this.form.length){var a=this.form.data("ui-form-reset-instances");a.splice(b.inArray(this,a),1);a.length?this.form.data("ui-form-reset-instances",a):this.form.removeData("ui-form-reset-instances").off("reset.ui-form-reset")}}}});
