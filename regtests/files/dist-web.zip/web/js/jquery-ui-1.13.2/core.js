/*
 jQuery UI :data 1.13.2
 http://jqueryui.com

 Copyright OpenJS Foundation and other contributors
 Released under the MIT license.
 http://jquery.org/license
 jQuery UI Disable Selection 1.13.2
 http://jqueryui.com

 Copyright OpenJS Foundation and other contributors
 Released under the MIT license.
 http://jquery.org/license
 jQuery UI Focusable 1.13.2
 http://jqueryui.com

 Copyright OpenJS Foundation and other contributors
 Released under the MIT license.
 http://jquery.org/license
 jQuery UI Keycode 1.13.2
 http://jqueryui.com

 Copyright OpenJS Foundation and other contributors
 Released under the MIT license.
 http://jquery.org/license
 jQuery UI Labels 1.13.2
 http://jqueryui.com

 Copyright OpenJS Foundation and other contributors
 Released under the MIT license.
 http://jquery.org/license
 jQuery UI Support for jQuery core 1.8.x and newer 1.13.2
 http://jqueryui.com

 Copyright OpenJS Foundation and other contributors
 Released under the MIT license.
 http://jquery.org/license

 jQuery UI Scroll Parent 1.13.2
 http://jqueryui.com

 Copyright OpenJS Foundation and other contributors
 Released under the MIT license.
 http://jquery.org/license
 jQuery UI Tabbable 1.13.2
 http://jqueryui.com

 Copyright OpenJS Foundation and other contributors
 Released under the MIT license.
 http://jquery.org/license
 jQuery UI Unique ID 1.13.2
 http://jqueryui.com

 Copyright OpenJS Foundation and other contributors
 Released under the MIT license.
 http://jquery.org/license
*/
(function(a){"function"===typeof define&&define.amd?define(["jquery"],a):a(jQuery)})(function(a){a.ui=a.ui||{};return a.ui.version="1.13.2"});(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.extend(a.expr.pseudos,{data:a.expr.createPseudo?a.expr.createPseudo(function(b){return function(c){return!!a.data(c,b)}}):function(b,c,d){return!!a.data(b,d[3])}})});
(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.fn.extend({disableSelection:function(){var b="onselectstart"in document.createElement("div")?"selectstart":"mousedown";return function(){return this.on(b+".ui-disableSelection",function(c){c.preventDefault()})}}(),enableSelection:function(){return this.off(".ui-disableSelection")}})});
(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){a.ui.focusable=function(b,c){var d=b.nodeName.toLowerCase();if("area"===d){c=b.parentNode;d=c.name;if(!b.href||!d||"map"!==c.nodeName.toLowerCase())return!1;b=a("img[usemap='#"+d+"']");return 0<b.length&&b.is(":visible")}/^(input|select|textarea|button|object)$/.test(d)?(c=!b.disabled)&&(d=a(b).closest("fieldset")[0])&&(c=!d.disabled):c="a"===d?b.href||c:c;if(c=c&&a(b).is(":visible")){b=a(b);
for(c=b.css("visibility");"inherit"===c;)b=b.parent(),c=b.css("visibility");c="visible"===c}return c};a.extend(a.expr.pseudos,{focusable:function(b){return a.ui.focusable(b,null!=a.attr(b,"tabindex"))}});return a.ui.focusable});(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.fn._form=function(){return"string"===typeof this[0].form?this.closest("form"):a(this[0].form)}});
(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.ui.ie=!!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase())});(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.ui.keyCode={BACKSPACE:8,COMMA:188,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SPACE:32,TAB:9,UP:38}});
(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.fn.labels=function(){var b;if(!this.length)return this.pushStack([]);if(this[0].labels&&this[0].labels.length)return this.pushStack(this[0].labels);var c=this.eq(0).parents("label");if(b=this.attr("id")){var d=this.eq(0).parents().last();d=d.add(d.length?d.siblings():this.siblings());b="label[for='"+a.escapeSelector(b)+"']";c=c.add(d.find(b).addBack(b))}return this.pushStack(c)}});
(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){a.expr.pseudos||(a.expr.pseudos=a.expr[":"]);a.uniqueSort||(a.uniqueSort=a.unique);if(!a.escapeSelector){var b=/([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g,c=function(d,e){return e?"\x00"===d?"�":d.slice(0,-1)+"\\"+d.charCodeAt(d.length-1).toString(16)+" ":"\\"+d};a.escapeSelector=function(d){return(d+"").replace(b,c)}}a.fn.even&&a.fn.odd||a.fn.extend({even:function(){return this.filter(function(d){return 0===
d%2})},odd:function(){return this.filter(function(d){return 1===d%2})}})});(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.ui.plugin={add:function(b,c,d){var e;b=a.ui[b].prototype;for(e in d)b.plugins[e]=b.plugins[e]||[],b.plugins[e].push([c,d[e]])},call:function(b,c,d,e){if((c=b.plugins[c])&&(e||b.element[0].parentNode&&11!==b.element[0].parentNode.nodeType))for(e=0;e<c.length;e++)b.options[c[e][0]]&&c[e][1].apply(b.element,d)}}});
(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.ui.safeActiveElement=function(b){try{var c=b.activeElement}catch(d){c=b.body}c||(c=b.body);c.nodeName||(c=b.body);return c}});(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.ui.safeBlur=function(b){b&&"body"!==b.nodeName.toLowerCase()&&a(b).trigger("blur")}});
(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.fn.scrollParent=function(b){var c=this.css("position"),d="absolute"===c,e=b?/(auto|scroll|hidden)/:/(auto|scroll)/;b=this.parents().filter(function(){var f=a(this);return d&&"static"===f.css("position")?!1:e.test(f.css("overflow")+f.css("overflow-y")+f.css("overflow-x"))}).eq(0);return"fixed"!==c&&b.length?b:a(this[0].ownerDocument||document)}});
(function(a){"function"===typeof define&&define.amd?define(["jquery","./version","./focusable"],a):a(jQuery)})(function(a){return a.extend(a.expr.pseudos,{tabbable:function(b){var c=a.attr(b,"tabindex"),d=null!=c;return(!d||0<=c)&&a.ui.focusable(b,d)}})});
(function(a){"function"===typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)})(function(a){return a.fn.extend({uniqueId:function(){var b=0;return function(){return this.each(function(){this.id||(this.id="ui-id-"+ ++b)})}}(),removeUniqueId:function(){return this.each(function(){/^ui-id-\d+$/.test(this.id)&&a(this).removeAttr("id")})}})});
